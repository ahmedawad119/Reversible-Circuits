
package creategrpaph;
import java.io.*;
import java.util.*;

class tableElement{
    String element[] = new String [4];
    public tableElement(String c1[], String c2[], String c3[]){
        for(int i =0;i<4;i++)
            element[i] = c1[i] + c2[i] + c3[i];
    }
    public tableElement(String c1[], String c2[]){
        for(int i =0;i<4;i++)
            element[i] = c1[i] + c2[i];
    }
    public tableElement(String c1[]){
        for(int i =0;i<4;i++)
            element[i] = c1[i];
    }
    public void print(){
        for(int i=0;i<4;i++)
            System.out.println(element[i]);
        System.out.println();
    }
}


public class CreateGraph {
    public static ArrayList<Node> nodes;
    public static ArrayList<Link> graph;
    public static ArrayList<String> setOfNodes;
    public static ArrayList<String> setOfNodes1;
    public static Map<String, tableElement> result;
    public static int numberOfVariables=0;
    public static int numberOfGates=0;
    public static String fileNameGlobal="";
    public static int maxLevel = 0;
    public static Node getNode(String name, ArrayList<Node> nodes){
        for(int i=0;i<nodes.size();i++)
            if(nodes.get(i).getName().equals(name)) return nodes.get(i);
        return null;
    }
    
    public static long getMin(long[] inputArray){ 
    long minValue = inputArray[0]; 
    for(int i=1;i<inputArray.length;i++){ 
      if(inputArray[i] < minValue){ 
        minValue = inputArray[i]; 
      } 
    } 
    return minValue; 
  } 
    
    public static long getMax(long[] inputArray){ 
    long maxValue = inputArray[0]; 
    for(int i=1;i < inputArray.length;i++){ 
      if(inputArray[i] > maxValue){ 
         maxValue = inputArray[i]; 
      } 
    } 
    return maxValue; 
  }
    public static boolean stillNotFinished(ArrayList<Link> g){
        for(int i=0;i<g.size(); i++)
            if(g.get(i).getLevel()==-1) return true;
        return false;
    }
    
    public static String []createGates(String gates[], String variables[], String Controls[], String XOR, int lines){
        for(int i=0;i<lines;i++){
            if(Arrays.binarySearch(Controls, variables[i])>=0) gates[i] = gates[i] + "–⚫–";
            else if(variables[i].equals(XOR)) gates[i] = gates[i] + "–⊕–";
            else gates[i] = gates[i] + "–––";
        }
        return gates;
    }
    
    public static void print(String variables[], String gates[]){
        for (int i=0;i<gates.length;i++)
            System.out.println(variables[i] + gates[i]);
    }
    public static String[] listOfVariables(String fileName){
        String Variables="";
        File file = new File(fileName);
        try{
            Scanner input = new Scanner(file);
            while(input.hasNext()){
                String data = input.nextLine();
                if(data.contains("inputs")){
                    int index = data.indexOf("inputs");
                    Variables = data.substring(index+7);
                }
            }
        }catch(Exception e){}
        return Variables.split(" ");
    }
    public static String numerOfTofolliGates(String fileName){
        File file = new File(fileName);
        String data="";
        String result="";
        int number=0;
        try{
            Scanner input = new Scanner(file);
            while(input.hasNext()){
                data = input.nextLine();
                if(data.contains("begin")){
                    data = input.nextLine();
                    result = data +",";
                    while(data.compareTo(".end")!=0){
                        data = input.nextLine();
                        result += data + ",";
                    }
                    return result;
                }
                    
            }
        }catch(Exception e){
        }
        return data;
    }
    public static void updateCodes(ArrayList<Node> nodes, ArrayList<Link> graph){
        for(int i=0;i<nodes.size();i++){
            int link1 = nodes.get(i).link1;
            int link2 = nodes.get(i).link2;
            if(nodes.get(i).Shape.compareTo("rect")==0) nodes.get(i).code="";
            else{
                if((link1==3 && link2==2) || (link1==2 && link2==3)) nodes.get(i).setCode("A");
                if((link1==3 && link2==1) || (link1==1 && link2==3)) nodes.get(i).setCode("B");
                if(link1==3 && link2==3) nodes.get(i).setCode("C");
                if(link1==2 && link2==2) nodes.get(i).setCode("D");
                if((link1==1 && link2==2) || (link1==2 && link2==1)) nodes.get(i).setCode("E");
                if(link1==1 && link2==1) nodes.get(i).setCode("F");  
            }
        }
        for(int i=0;i<graph.size();i++){
            //if(graph.get(i).From.Shape.compareTo("rect")!=0){
            if(graph.get(i).From.getCode().compareTo("A")==0)
                graph.get(i).From.setCode("A"+graph.get(i).To.getCode());
            else if(graph.get(i).From.getCode().compareTo("B")==0)
                graph.get(i).From.setCode("B"+graph.get(i).To.getCode());
            else if(graph.get(i).From.getCode().compareTo("C")==0)
                graph.get(i).From.setCode("C"+graph.get(i).To.getCode());
            else if(graph.get(i).From.getCode().compareTo("D")==0)
                graph.get(i).From.setCode("D"+graph.get(i).To.getCode());
            else if(graph.get(i).From.getCode().compareTo("E")==0)
                graph.get(i).From.setCode("E"+graph.get(i).To.getCode());
            else if(graph.get(i).From.getCode().compareTo("F")==0)
                graph.get(i).From.setCode("F"+graph.get(i).To.getCode());
            String c = graph.get(i).From.getCode();
            if(c.length()>3) graph.get(i).From.setCode(c.substring(0,2));
        }
    }
    public static void oneToOne(){
        File file = new File(fileNameGlobal + ".out");
        
           
        
        try{
            Scanner input = new Scanner(file);
            while(input.hasNext()){
                String data = input.nextLine();
                if(data.contains("label")){
                    int index = data.indexOf("[");
                    String name = data.substring(0, index);
                    String shape;
                    int level = -1;

                    int pos1 = data.indexOf("label");
                    int pos2 = data.indexOf("]");
                    String label = data.substring(pos1+7, pos2-1);
                    if(data.contains("rectangle")) {
                        shape="rect";
                    if(!label.equals("1") && !label.equals("0")) level = 0;
                    }else shape="oval";
                    if(level==0) setOfNodes.add(name);
                    Node n = new Node(name,shape, label, level, 0, 0, -1, -1, "");
                    nodes.add(n);
                }
                if(data.contains("->")){
                    int pos1 = data.indexOf("->");
                    int pos2 = data.indexOf(">");
                    int pos3 = data.indexOf(" ");
                    String labelFrom = data.substring(0,pos1);
                    String labelTo = data.substring(pos2+1, pos3);
                    Node from = getNode(labelFrom, nodes);
                    from.setOutLinks(from.getOutLinks()+1);
                    Node to = getNode(labelTo, nodes);  
                    to.setInLinks(to.getInLinks()+1);
                    String Style="";
                    if(data.contains("dashed")) Style="dashed";
                    graph.add(new Link(from, to, Style));
                }
            }
            input.close();
        }
	catch(Exception e){};
        
        int levelCounter = 1;
        while(stillNotFinished(graph)){
            for(int i=0;i<graph.size();i++){
                if(setOfNodes.contains(graph.get(i).getFrom().getName())){
                    if(graph.get(i).getLevel()==-1)
                    graph.get(i).setLevel(levelCounter);
                    setOfNodes1.add(graph.get(i).getNameTo());
                }
            }
            setOfNodes.clear();
            setOfNodes = new ArrayList<>(setOfNodes1);
            setOfNodes1.clear();
            levelCounter++;
        }
        maxLevel = levelCounter;
        updateCodes(nodes, graph);
        
        //System.out.println("Name\tShape\tLabel\tLevel\tinLinks\toutLinks");
        //for(int i=0;i<nodes.size();i++)
            //nodes.get(i).print();
        //for(int i=0;i<graph.size();i++){
            //graph.get(i).print();
            //System.out.println(graph.get(i).To.Label);
            //checkStatus(graph.get(i));
        //}
        
        //-----------------------------------------------
        
        String []Variables=listOfVariables(fileNameGlobal + ".real");
        numberOfVariables = Variables.length;
        
        String Tofolli = numerOfTofolliGates(fileNameGlobal + ".real");
        String gates[] = Tofolli.split(",");
        numberOfGates = gates.length;
        
        String gate[][] = new String[numberOfVariables][gates.length-1];
        for(int i=0;i<numberOfVariables;i++)
            for(int j=0;j<gates.length-1;j++)
                gate[i][j]="―――";
        
        
        for(int cols=0;cols<gates.length-1;cols++){
            String col[] = gates[cols].split(" ");
            int p=0, position;
            for(position=1;position<col.length-1;position++){
                p = Integer.parseInt(col[position].substring(1));
                gate[p][cols]="―●―";
            }
            p = Integer.parseInt(col[col.length-1].substring(1));
            gate[p][cols]="―⊕―";
        }
        //for(int i=0;i<numberOfVariables;i++){
        //    for(int j=0;j<gates.length-1;j++)
                //System.out.print(gate[i][j]);
        //    System.out.println();
        //}
        
        //gates = createGates(gates, variables, Controls, XOR, 5);
        
        
        
        
    }
    public static void createLookUpTable(){
        String c1[]= new String[4];
        String c2[]= new String[4];
        String c3[]= new String[4];
        String c4[]= new String[4];
        String c5[]= new String[4];
        String c6[]= new String[4];
        
        for(int i=0;i<4;i++){
            c1[i] = "―――――――――";
            c2[i] = "―――――――――";
            c3[i] = "―――――――――";
            c4[i] = "―――――――――";
            c5[i] = "―――――――――";
            c6[i] = "―――――――――";
        }
        
        c1[0] = "―⊕――⊕――⊕―";
        c1[1] = "―●―――――●―";
        c1[2] = "―●――●――――";
        c1[3] = "―――――――●―";
        
        c2[0] = "―⊕――⊕――――";
        c2[1] = "―●―――――――";
        c2[2] = "―●――●――――";
        
        c3[0] = "―⊕――⊕――⊕―";
        c3[1] = "―●―――――●―";
        c3[2] = "―●――●――――";
        
        c4[0] = "―⊕―――――――";
        c4[1] = "―●―――――――";
        c4[2] = "―●―――――――";
        
        c5[0] = "―⊕――⊕――――";
        c5[1] = "―●――●――――";
        c5[2] = "――――●――――";
        
        c6[0] = "―⊕―――――――";
        c6[1] = "―●―――――――";
        
        
        
        result.put("AAA",new tableElement(c1, c1, c1));
        result.put("AAB",new tableElement(c1, c1, c2));
        result.put("AAC",new tableElement(c1, c1, c3));
        result.put("AAD",new tableElement(c1, c1, c4));
        result.put("AAE",new tableElement(c1, c1, c5));
        result.put("AAF",new tableElement(c1, c1, c6));
        result.put("ABA",new tableElement(c1, c2, c1));
        result.put("ACA",new tableElement(c1, c3, c1));
        result.put("ADA",new tableElement(c1, c4, c1));
        result.put("AEA",new tableElement(c1, c5, c1));
        result.put("AFA",new tableElement(c1, c6, c1));
        
        result.put("BA",new tableElement(c2, c1));
        result.put("BB",new tableElement(c2, c2));
        result.put("BC",new tableElement(c2, c3));
        result.put("BD",new tableElement(c2, c4));
        result.put("BE",new tableElement(c2, c5));
        result.put("BF",new tableElement(c2, c6));
        result.put("CA",new tableElement(c3, c1));
        result.put("CB",new tableElement(c3, c2));
        result.put("CC",new tableElement(c3, c3));
        result.put("CF",new tableElement(c3, c4));
        result.put("CE",new tableElement(c3, c5));
        result.put("CF",new tableElement(c3, c6));
        result.put("DA",new tableElement(c4, c1));
        result.put("DB",new tableElement(c4, c2));
        result.put("DC",new tableElement(c4, c3));
        result.put("DD",new tableElement(c4, c4));
        result.put("DE",new tableElement(c4, c5));
        result.put("DF",new tableElement(c4, c6));
        result.put("EA",new tableElement(c5, c1));
        result.put("EB",new tableElement(c5, c2));
        result.put("EC",new tableElement(c5, c3));
        result.put("ED",new tableElement(c5, c4));
        result.put("EE",new tableElement(c5, c5));
        result.put("EF",new tableElement(c5, c6));
        result.put("F",new tableElement(c6));
        
        Set<String> s = result.keySet();
        //System.out.println(s);
        //System.out.println(s.size()); 
    }
    public static void generateCircuits(){
        ArrayList<Integer> levels = new ArrayList();
        for(int i=maxLevel;i>=0; i=i-2)
            levels.add(i);
        for(int i=0;i<nodes.size();i++){
            //System.out.println(nodes.get(i).getCode());
            int level = nodes.get(i).getLevel();
            if(levels.contains(level)){
                String code = nodes.get(i).getCode();
                //if(result.containsKey(code)) result.get(code).print();                        
            }
        }
    }
    public static void main(String[] args) {
        int numberOfTries = 5;
        int numberOfCircuits = 133;
                
        long average1[] = new long[numberOfCircuits];
        long average2[] = new long[numberOfCircuits];
        try{
            FileWriter output = new FileWriter("output.txt");
            for(int i=0;i<numberOfCircuits;i++){
                average1[i] = average2[i] = 0;
            }
            for(int counter=1;counter<=numberOfTries;counter++){
                output.write("Counter" + Integer.toString(counter)
                + "---------------------------------\n");
                for(int i=1;i<=numberOfCircuits;i++){
                    nodes = new ArrayList<>();
                    graph = new ArrayList<>();
                    setOfNodes = new ArrayList<>();
                    setOfNodes1 = new ArrayList<>();
                    result = new HashMap<>();
                    fileNameGlobal = Integer.toString(i);
                    long time1 = System.nanoTime();
                    oneToOne();
                    time1 = System.nanoTime()-time1;
                    createLookUpTable();
                    long time2 = System.nanoTime();
                    generateCircuits();
                    time2 = System.nanoTime()-time2;
                    average1[i-1] += time1/1000;
                    average2[i-1] += time2/1000;
                    //System.out.println(time1);
                    //System.out.println(time2);
                    output.write(Long.toString(time1));
                    output.write("\t");
                    output.write(Long.toString(time2));
                    output.write("\t");
                    output.write(Integer.toString(numberOfVariables));
                    output.write("\t");
                    output.write(Integer.toString(nodes.size()));
                    output.write("\t");
                    output.write(Integer.toString(graph.size()));
                    output.write("\t");
                    output.write(Integer.toString(numberOfGates));
                    
                    output.write("\n");
                }
            }
            output.write("Average:---------------------------------\n");
            output.write("1-1 \t sub \t ratio\n");
            
            //for(int i=0;i<numberOfCircuits;i++){
            //    output.write(Double.toString(1.0*average[i][0]/numberOfTries));
            //    output.write(",");
            //}
            
            long max1 = getMax(average1);
            long min1 = getMin(average1);
            long max2 = getMax(average2);
            long min2 = getMin(average2);
            
            for(int i=0;i<numberOfCircuits;i++){
                output.write(Double.toString(100.0*(average1[i]-min1)/(max1-min1)));
                output.write("\n");
            }
            output.write("\n");
            for(int i=0;i<numberOfCircuits;i++){
                output.write(Double.toString(100.0*(average2[i]-min2)/(max2-min2)));
                output.write("\n");
                //output.write(Double.toString(100*(1.0*average[i][1]/numberOfTries)
                ///(1.0*average[i][0]/numberOfTries)));
            }
            output.write("\n");
            output.close();
        }catch(Exception e){System.out.println(e.toString());}
        
    }
}
