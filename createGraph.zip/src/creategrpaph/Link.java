/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package creategrpaph;

/**
 *
 * @author amjad
 */
public class Link {
    Node From;
    Node To;
    String Style;
    Link(Node from, Node to, String s){
        From = from;
        To = to;
        Style = s;
        if(from.Label=="d:0"){
            
        }
        if(to.Shape.compareTo("rect")==0 && to.Label.compareTo("1")==0 && Style.compareTo("dashed")==0)
            from.link1=1;
        else if(to.Shape.compareTo("rect")==0 && to.Label.compareTo("0")==0 && Style.length()==0)
            from.link2=1;
        else if(to.Shape.compareTo("oval")==0 && Style.length()==0)
            from.link2=2;
        else if(to.Shape.compareTo("rect")==0 && to.Label.compareTo("0")==0 && Style.compareTo("dashed")==0)
            from.link1=2;
        else if(to.Shape.compareTo("oval")==0 && Style.compareTo("dashed")==0)
            from.link1=3;
        else if(to.Shape.compareTo("rect")==0 && to.Label.compareTo("1")==0 && Style.length()==0)
            from.link2=3;
    }
    void print(){
        From.printName();
        System.out.print("->");
        To.printName();
        System.out.println();
    }
    
    int getLevel(){
        return To.getLevel();
    }
    Node getFrom(){
        return From;
    }
    void setLevel(int level){
        To.setLevel(level);
    }
    String getNameTo(){
        return To.getName();
    }
}
