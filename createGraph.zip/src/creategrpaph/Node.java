/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package creategrpaph;

/**
 *
 * @author amjad
 */
public class Node {
    String Name;
    String Shape;
    String Label;
    int Level;
    int inLinks;
    int outLinks;
    int link1;
    int link2;
    String code;
    Node(String name, String shape, String label, int level, int in, int out, int l1, int l2, String c){
        Name = name;
        Shape = shape;
        Label = label;
        Level = level;
        inLinks=in;
        outLinks = out;
        link1 = l1;
        link2 = l2;
        code = c;
    }
    Node(String name){
        Name = name;
    }
    String getName(){
        return Name;
    }
    void print(){
        System.out.println(Name + "\t" + Shape + "\t" +
                Label + "\t" + Level + "\t" + inLinks + "\t" + outLinks +
                "\t" + link1 +"\t" + link2 + "\t" + code);
    }
    void printName(){
        System.out.print(Name);
    }
    void setLevel(int level){
        Level = level;
    }
    int getLevel(){
        return Level;
    }
    int getInLinks(){
        return inLinks;
    }
    int getOutLinks(){
        return outLinks;
    }
    void setInLinks(int in){
        inLinks = in;
    }
    void setOutLinks(int out){
        outLinks = out;
    }
    int getLink1(){
        return link1;
    }
    int getLink2(){
        return link2;
    }
    void setLink1(int l1){
        link1 = l1;
    }
    void setLink2(int l2){
        link2 = l2;
    }
    String getCode(){
        return code;
    }
    void setCode(String c){
        code = c;
    }
}
